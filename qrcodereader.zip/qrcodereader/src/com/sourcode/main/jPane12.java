/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sourcode.main;

import com.github.sarxos.webcam.WebcamPanel;
import org.netbeans.lib.awtextra.AbsoluteConstraints;

/**
 *
 * @author user
 */
class jPane12 {

    static void add(WebcamPanel panel, AbsoluteConstraints absoluteConstraints) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
